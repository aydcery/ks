
import React, { useState, useEffect } from 'react';
import { 
  StyleSheet, 
  View, 
  Text, 
  SafeAreaView, 
  TouchableOpacity, 
  StatusBar, 
  ScrollView,
  Modal,
  ActivityIndicator,
  Platform
} from 'react-native';
import { 
  PlusCircle, 
  Image as ImageIcon, 
  Settings, 
  Sparkles, 
  Wand2, 
  Monitor, 
  Layers,
  ExternalLink,
  LogOut,
  User,
  ShieldCheck,
  ChevronRight,
  Coins,
  CreditCard,
  X
} from 'lucide-react-native';
import { ImageEditor } from './components/ImageEditor';
import { HistoryGallery } from './components/HistoryGallery';
import { Login } from './components/Login';

export interface UserProfile {
  name: string;
  email: string;
  provider: 'Apple' | 'Google';
  credits: number;
}

type Tab = 'create' | 'gallery' | 'settings';

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('create');
  const [history, setHistory] = useState<any[]>([]);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [showStore, setShowStore] = useState(false);
  const [isPurchasing, setIsPurchasing] = useState(false);

  // Simulation: No API Key check UI for Native, assumed handled in environment
  
  const handleLogin = (profile: UserProfile) => {
    setUser(profile);
  };

  const handleLogout = () => {
    setUser(null);
    setActiveTab('create');
  };

  const deductCredit = () => {
    if (user && user.credits > 0) {
      setUser({ ...user, credits: user.credits - 1 });
      return true;
    }
    return false;
  };

  const buyCredits = (amount: number) => {
    setIsPurchasing(true);
    setTimeout(() => {
      if (user) {
        setUser({ ...user, credits: user.credits + amount });
      }
      setIsPurchasing(false);
      setShowStore(false);
    }, 2000);
  };

  const addToHistory = (original: string, result: string) => {
    setHistory([{
      id: Math.random().toString(36).substr(2, 9),
      original,
      result,
      timestamp: Date.now()
    }, ...history]);
  };

  if (!user) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />
      
      {/* iOS Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.headerLabel}>VIBE STUDIO</Text>
          <Text style={styles.headerTitle}>
            {activeTab === 'create' ? 'New Staging' : activeTab === 'gallery' ? 'Portfolio' : 'Account'}
          </Text>
        </View>
        <View style={styles.headerActions}>
          <TouchableOpacity 
            onPress={() => setShowStore(true)}
            style={styles.creditPill}
          >
            <Coins size={12} color="#111827" />
            <Text style={styles.creditText}>{user.credits}</Text>
          </TouchableOpacity>
          <View style={styles.avatar}>
            <User size={14} color="#6B7280" />
          </View>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {activeTab === 'create' && (
          <View style={styles.tabContent}>
            <View style={styles.promoCard}>
              <View style={styles.promoIcon}>
                <Wand2 size={20} color="#FFFFFF" />
              </View>
              <View>
                <Text style={styles.promoTitle}>Pro Studio</Text>
                <Text style={styles.promoDesc}>Professional environment replacement.</Text>
              </View>
            </View>
            <ImageEditor 
              credits={user.credits}
              onProcessed={addToHistory}
              onDeductCredit={deductCredit}
              onNeedsCredits={() => setShowStore(true)}
            />
          </View>
        )}

        {activeTab === 'gallery' && (
          <View style={styles.tabContent}>
            {history.length > 0 ? (
              <HistoryGallery items={history} />
            ) : (
              <View style={styles.emptyState}>
                <ImageIcon size={48} color="#E5E7EB" strokeWidth={1} />
                <Text style={styles.emptyText}>No projects yet</Text>
              </View>
            )}
          </View>
        )}

        {activeTab === 'settings' && (
          <View style={styles.tabContent}>
            <View style={styles.profileCard}>
              <View style={styles.profileAvatarLarge}>
                <User size={32} color="#111827" />
              </View>
              <View>
                <Text style={styles.profileName}>{user.name}</Text>
                <Text style={styles.profileEmail}>{user.email}</Text>
                <View style={styles.verifiedRow}>
                  <ShieldCheck size={10} color="#111827" />
                  <Text style={styles.verifiedText}>Verified {user.provider}</Text>
                </View>
              </View>
            </View>

            <View style={styles.settingsList}>
              <TouchableOpacity style={styles.settingsItem} onPress={() => setShowStore(true)}>
                <View style={styles.settingsItemLeft}>
                  <View style={styles.settingsIconBox}><Coins size={16} color="#111827" /></View>
                  <Text style={styles.settingsItemLabel}>Credit Balance</Text>
                </View>
                <View style={styles.settingsItemRight}>
                  <Text style={styles.settingsValue}>{user.credits} Available</Text>
                  <ChevronRight size={16} color="#E5E7EB" />
                </View>
              </TouchableOpacity>
              <View style={styles.settingsItem}>
                <View style={styles.settingsItemLeft}>
                  <View style={styles.settingsIconBox}><Layers size={16} color="#111827" /></View>
                  <Text style={styles.settingsItemLabel}>Staging Quality</Text>
                </View>
                <Text style={styles.settingsBadge}>ULTRA-HD</Text>
              </View>
            </View>

            <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
              <LogOut size={18} color="#111827" />
              <Text style={styles.logoutText}>Sign Out</Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>

      {/* Credit Store Sheet */}
      <Modal visible={showStore} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <TouchableOpacity style={styles.modalCloseArea} onPress={() => !isPurchasing && setShowStore(false)} />
          <View style={styles.modalContent}>
            <View style={styles.modalHandle} />
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Refill Credits</Text>
              <TouchableOpacity onPress={() => setShowStore(false)} style={styles.modalCloseBtn}>
                <X size={18} color="#9CA3AF" />
              </TouchableOpacity>
            </View>

            {[
              { amount: 5, price: '$1.99', label: 'Starter Pack' },
              { amount: 20, price: '$4.99', label: 'Studio Pack', popular: true },
              { amount: 50, price: '$9.99', label: 'Pro Pack' },
            ].map((pack) => (
              <TouchableOpacity
                key={pack.amount}
                onPress={() => buyCredits(pack.amount)}
                style={[styles.packItem, pack.popular && styles.packItemPopular]}
              >
                <View style={styles.packInfo}>
                  <View style={styles.packIconBox}><Coins size={24} color="#111827" /></View>
                  <View>
                    <Text style={styles.packAmount}>{pack.amount} Credits</Text>
                    <Text style={styles.packLabel}>{pack.label}</Text>
                  </View>
                </View>
                <View style={styles.packPriceBox}>
                  <Text style={styles.packPrice}>{pack.price}</Text>
                  {pack.popular && <Text style={styles.bestValue}>BEST VALUE</Text>}
                </View>
              </TouchableOpacity>
            ))}

            <View style={styles.iapFooter}>
              <CreditCard size={14} color="#9CA3AF" />
              <Text style={styles.iapFooterText}>SECURED BY APPLE PAY</Text>
            </View>
          </View>
        </View>
        {isPurchasing && (
          <View style={styles.purchasingOverlay}>
            <ActivityIndicator color="#FFFFFF" size="large" />
            <Text style={styles.purchasingText}>Authorizing...</Text>
          </View>
        )}
      </Modal>

      {/* iOS Tab Bar */}
      <View style={styles.tabBar}>
        <TouchableOpacity onPress={() => setActiveTab('create')} style={styles.tabItem}>
          <PlusCircle size={22} color={activeTab === 'create' ? '#111827' : '#D1D5DB'} strokeWidth={activeTab === 'create' ? 2.5 : 2} />
          <Text style={[styles.tabText, activeTab === 'create' && styles.tabTextActive]}>STUDIO</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => setActiveTab('gallery')} style={styles.tabItem}>
          <ImageIcon size={22} color={activeTab === 'gallery' ? '#111827' : '#D1D5DB'} strokeWidth={activeTab === 'gallery' ? 2.5 : 2} />
          <Text style={[styles.tabText, activeTab === 'gallery' && styles.tabTextActive]}>LIBRARY</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => setActiveTab('settings')} style={styles.tabItem}>
          <Settings size={22} color={activeTab === 'settings' ? '#111827' : '#D1D5DB'} strokeWidth={activeTab === 'settings' ? 2.5 : 2} />
          <Text style={[styles.tabText, activeTab === 'settings' && styles.tabTextActive]}>ACCOUNT</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FFFFFF' },
  header: { paddingHorizontal: 24, paddingTop: 20, paddingBottom: 16, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  headerLabel: { fontSize: 10, fontWeight: '800', color: '#9CA3AF', letterSpacing: 2 },
  headerTitle: { fontSize: 28, fontWeight: '800', color: '#111827', marginTop: 2 },
  headerActions: { flexDirection: 'row', alignItems: 'center' },
  creditPill: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#F3F4F6', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 20, paddingHorizontal: 10, paddingVertical: 4, marginRight: 8 },
  creditText: { fontSize: 11, fontWeight: '700', marginLeft: 6, color: '#111827' },
  avatar: { width: 28, height: 28, borderRadius: 14, backgroundColor: '#F3F4F6', borderWidth: 1, borderColor: '#E5E7EB', alignItems: 'center', justifyContent: 'center' },
  content: { paddingHorizontal: 24, paddingBottom: 100 },
  tabContent: { marginTop: 10 },
  promoCard: { backgroundColor: '#F3F4F6', borderRadius: 24, padding: 20, flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: '#E5E7EB' },
  promoIcon: { width: 40, height: 40, borderRadius: 12, backgroundColor: '#111827', alignItems: 'center', justifyContent: 'center', marginRight: 16 },
  promoTitle: { fontSize: 14, fontWeight: '800', color: '#111827' },
  promoDesc: { fontSize: 12, color: '#6B7280', marginTop: 2 },
  emptyState: { paddingVertical: 80, alignItems: 'center' },
  emptyText: { fontSize: 13, color: '#D1D5DB', fontWeight: '600', marginTop: 16 },
  profileCard: { backgroundColor: '#FFFFFF', borderRadius: 24, padding: 24, borderWidth: 1, borderColor: '#E5E7EB', flexDirection: 'row', alignItems: 'center' },
  profileAvatarLarge: { width: 56, height: 56, borderRadius: 28, backgroundColor: '#F3F4F6', borderWidth: 1, borderColor: '#E5E7EB', alignItems: 'center', justifyContent: 'center', marginRight: 16 },
  profileName: { fontSize: 18, fontWeight: '800', color: '#111827' },
  profileEmail: { fontSize: 12, color: '#6B7280', marginTop: 2 },
  verifiedRow: { flexDirection: 'row', alignItems: 'center', marginTop: 6 },
  verifiedText: { fontSize: 9, fontWeight: '800', color: '#111827', letterSpacing: 1, marginLeft: 4, textTransform: 'uppercase' },
  settingsList: { marginTop: 24, backgroundColor: '#FFFFFF', borderRadius: 24, borderWidth: 1, borderColor: '#E5E7EB', overflow: 'hidden' },
  settingsItem: { padding: 16, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  settingsItemLeft: { flexDirection: 'row', alignItems: 'center' },
  settingsIconBox: { width: 32, height: 32, borderRadius: 10, backgroundColor: '#F3F4F6', alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  settingsItemLabel: { fontSize: 14, fontWeight: '700', color: '#111827' },
  settingsItemRight: { flexDirection: 'row', alignItems: 'center' },
  settingsValue: { fontSize: 12, color: '#9CA3AF', fontWeight: '600', marginRight: 8 },
  settingsBadge: { fontSize: 9, fontWeight: '800', color: '#9CA3AF', backgroundColor: '#F3F4F6', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4 },
  logoutBtn: { marginTop: 24, backgroundColor: '#FFFFFF', borderRadius: 20, padding: 16, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', borderWidth: 1, borderColor: '#E5E7EB' },
  logoutText: { marginLeft: 8, fontSize: 14, fontWeight: '700', color: '#111827' },
  tabBar: { position: 'absolute', bottom: 0, left: 0, right: 0, height: 90, backgroundColor: 'rgba(255, 255, 255, 0.95)', borderTopWidth: 0.5, borderTopColor: '#E5E7EB', flexDirection: 'row', justifyContent: 'space-around', paddingHorizontal: 20, paddingTop: 10 },
  tabItem: { alignItems: 'center', width: 80 },
  tabText: { fontSize: 8, fontWeight: '800', letterSpacing: 1, marginTop: 4, color: '#D1D5DB' },
  tabTextActive: { color: '#111827' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0, 0, 0, 0.4)', justifyContent: 'flex-end' },
  modalCloseArea: { flex: 1 },
  modalContent: { backgroundColor: '#FFFFFF', borderTopLeftRadius: 40, borderTopRightRadius: 40, padding: 24, paddingBottom: 60 },
  modalHandle: { width: 40, height: 4, backgroundColor: '#F3F4F6', borderRadius: 2, alignSelf: 'center', marginBottom: 20 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 },
  modalTitle: { fontSize: 20, fontWeight: '800', color: '#111827' },
  modalCloseBtn: { width: 32, height: 32, borderRadius: 16, backgroundColor: '#F3F4F6', alignItems: 'center', justifyContent: 'center' },
  packItem: { padding: 16, borderRadius: 24, borderWidth: 1, borderColor: '#F3F4F6', backgroundColor: '#FFFFFF', marginBottom: 12, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  packItemPopular: { borderColor: '#111827', backgroundColor: '#F9FAFB' },
  packInfo: { flexDirection: 'row', alignItems: 'center' },
  packIconBox: { width: 48, height: 48, borderRadius: 16, backgroundColor: '#F3F4F6', alignItems: 'center', justifyContent: 'center', marginRight: 16 },
  packAmount: { fontSize: 15, fontWeight: '800', color: '#111827' },
  packLabel: { fontSize: 10, fontWeight: '700', color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: 1, marginTop: 2 },
  packPriceBox: { alignItems: 'flex-end' },
  packPrice: { fontSize: 14, fontWeight: '900', color: '#111827' },
  bestValue: { fontSize: 8, fontWeight: '800', color: '#111827', marginTop: 4 },
  iapFooter: { marginTop: 32, flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  iapFooterText: { fontSize: 9, fontWeight: '800', color: '#9CA3AF', letterSpacing: 1.5, marginLeft: 6 },
  purchasingOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0, 0, 0, 0.6)', alignItems: 'center', justifyContent: 'center' },
  purchasingText: { color: '#FFFFFF', fontSize: 10, fontWeight: '800', letterSpacing: 2, marginTop: 16 }
});
