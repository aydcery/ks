
import React from 'react';
import { StyleSheet, View, Text, Image, TouchableOpacity, FlatList } from 'react-native';
import { ExternalLink, Calendar } from 'lucide-react-native';

interface HistoryGalleryProps {
  items: { id: string; original: string; result: string; timestamp: number }[];
}

export const HistoryGallery: React.FC<HistoryGalleryProps> = ({ items }) => {
  const renderItem = ({ item }: any) => (
    <View style={styles.card}>
      <Image source={{ uri: item.result }} style={styles.thumbnail} />
      <View style={styles.info}>
        <View style={styles.dateRow}>
          <Calendar size={10} color="#D1D5DB" />
          <Text style={styles.dateText}>
            {new Date(item.timestamp).toLocaleDateString()}
          </Text>
        </View>
        <Text style={styles.title}>PROJECT SHOT</Text>
        <Text style={styles.desc}>Staged Environment</Text>
      </View>
      <TouchableOpacity style={styles.actionBtn}>
        <ExternalLink size={14} color="#D1D5DB" />
      </TouchableOpacity>
    </View>
  );

  return (
    <FlatList
      data={items}
      renderItem={renderItem}
      keyExtractor={item => item.id}
      contentContainerStyle={styles.list}
      showsVerticalScrollIndicator={false}
      scrollEnabled={false} // Managed by parent ScrollView in App.tsx
    />
  );
};

const styles = StyleSheet.create({
  list: { paddingBottom: 20 },
  card: { backgroundColor: '#FFFFFF', borderRadius: 24, padding: 12, flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: '#F3F4F6', marginBottom: 12 },
  thumbnail: { width: 64, height: 64, borderRadius: 16, backgroundColor: '#F9FAFB', borderWidth: 1, borderColor: '#F3F4F6' },
  info: { flex: 1, marginLeft: 16 },
  dateRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 4 },
  dateText: { fontSize: 9, fontWeight: '800', color: '#D1D5DB', textTransform: 'uppercase', letterSpacing: 1, marginLeft: 4 },
  title: { fontSize: 12, fontWeight: '800', color: '#111827', letterSpacing: 0.5 },
  desc: { fontSize: 10, color: '#9CA3AF', fontWeight: '600', marginTop: 2 },
  actionBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: '#F9FAFB', alignItems: 'center', justifyContent: 'center' }
});
