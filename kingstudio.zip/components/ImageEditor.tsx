
import React, { useState } from 'react';
import { 
  StyleSheet, 
  View, 
  Text, 
  TouchableOpacity, 
  Image,
  ActivityIndicator,
  ScrollView,
  Alert
} from 'react-native';
import { 
  Camera, 
  Briefcase, 
  Shirt, 
  Sofa, 
  Smartphone,
  ChevronLeft, 
  Download, 
  Sparkles, 
  AlertCircle, 
  Coins,
  Check
} from 'lucide-react-native';
import { generateProductImage } from '../services/geminiService';

interface ImageEditorProps {
  onProcessed: (original: string, result: string) => void;
  credits: number;
  onDeductCredit: () => boolean;
  onNeedsCredits: () => void;
}

type Step = 'category' | 'upload' | 'config' | 'processing' | 'result';

export const ImageEditor: React.FC<ImageEditorProps> = ({ onProcessed, credits, onDeductCredit, onNeedsCredits }) => {
  const [step, setStep] = useState<Step>('category');
  const [image, setImage] = useState<string | null>(null);
  const [category, setCategory] = useState<string | null>(null);
  const [options, setOptions] = useState<any>({ aspectRatio: '1:1', quality: 'Standard' });
  const [resultImage, setResultImage] = useState<string | null>(null);

  const selectImage = () => {
    // In a real app, use react-native-image-picker here
    // Mocking an image selection:
    setImage('https://placehold.co/600x600/F3F4F6/9CA3AF?text=User+Product');
    setStep('config');
  };

  const processImage = async () => {
    if (credits <= 0) {
      onNeedsCredits();
      return;
    }

    setStep('processing');
    try {
      const result = await generateProductImage('mock_base64', {
        ...options,
        category: category as any
      });
      
      if (result) {
        onDeductCredit();
        setResultImage(result);
        setStep('result');
        onProcessed(image!, result);
      }
    } catch (err) {
      Alert.alert('Error', 'Staging failed. Please try again.');
      setStep('config');
    }
  };

  const OptionGroup = ({ label, items, value, onChange }: any) => (
    <View style={styles.optionGroup}>
      <Text style={styles.optionLabel}>{label}</Text>
      <View style={styles.optionRow}>
        {items.map((opt: string) => (
          <TouchableOpacity 
            key={opt}
            onPress={() => onChange(opt)}
            style={[styles.optionBtn, value === opt && styles.optionBtnActive]}
          >
            <Text style={[styles.optionBtnText, value === opt && styles.optionBtnTextActive]}>{opt}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      {step === 'category' && (
        <View style={styles.grid}>
          {[
            { id: 'Accessories', icon: Briefcase },
            { id: 'Clothes', icon: Shirt },
            { id: 'Furniture', icon: Sofa },
            { id: 'Electronics', icon: Smartphone },
          ].map((cat) => (
            <TouchableOpacity
              key={cat.id}
              onPress={() => { setCategory(cat.id); setStep('upload'); }}
              style={styles.catBtn}
            >
              <View style={styles.catIconBox}><cat.icon size={20} color="#111827" /></View>
              <Text style={styles.catLabel}>{cat.id}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      {step === 'upload' && (
        <View style={styles.uploadArea}>
          <TouchableOpacity onPress={() => setStep('category')} style={styles.backBtn}>
            <ChevronLeft size={20} color="#9CA3AF" />
            <Text style={styles.backText}>{category}</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={selectImage} style={styles.dropzone}>
            <View style={styles.dropIcon}><Camera size={28} color="#111827" /></View>
            <Text style={styles.dropTitle}>Tap to Upload</Text>
            <Text style={styles.dropSub}>JPG OR PNG</Text>
          </TouchableOpacity>
        </View>
      )}

      {step === 'config' && (
        <View style={styles.configArea}>
          <TouchableOpacity onPress={() => setStep('upload')} style={styles.backBtn}>
            <ChevronLeft size={20} color="#9CA3AF" />
            <Text style={styles.backText}>CONFIGURATION</Text>
          </TouchableOpacity>

          <View style={styles.configCard}>
            <OptionGroup 
              label="RATIO" 
              items={['1:1', '4:5', '16:9']} 
              value={options.aspectRatio} 
              onChange={(v: any) => setOptions({...options, aspectRatio: v})} 
            />
            <OptionGroup 
              label="STAGING DETAIL" 
              items={['Standard', 'High']} 
              value={options.quality} 
              onChange={(v: any) => setOptions({...options, quality: v})} 
            />
          </View>

          <TouchableOpacity onPress={processImage} style={styles.primaryBtn}>
            <View style={styles.btnContent}>
              <Sparkles size={16} color="#FFFFFF" />
              <Text style={styles.btnText}>Start Staging</Text>
            </View>
            <View style={styles.creditCost}>
              <Coins size={12} color="rgba(255,255,255,0.6)" />
              <Text style={styles.creditCostText}>1</Text>
            </View>
          </TouchableOpacity>
        </View>
      )}

      {step === 'processing' && (
        <View style={styles.loaderArea}>
          <View style={styles.loaderBox}>
            <ActivityIndicator color="#111827" size="large" />
          </View>
          <Text style={styles.loaderTitle}>RENDERING...</Text>
          <Text style={styles.loaderSub}>Synthesizing lighting and textures</Text>
        </View>
      )}

      {step === 'result' && (
        <View style={styles.resultArea}>
          <View style={styles.resultHeader}>
            <Text style={styles.resultTitle}>STAGING READY</Text>
            <View style={styles.certifiedBadge}>
              <Check size={10} color="#FFFFFF" strokeWidth={3} />
              <Text style={styles.certifiedText}>CERTIFIED</Text>
            </View>
          </View>
          
          <View style={styles.imageContainer}>
            <Image source={{ uri: resultImage! }} style={styles.resultImage} resizeMode="cover" />
          </View>

          <View style={styles.resultActions}>
            <TouchableOpacity style={styles.secondaryBtn}>
              <Download size={16} color="#111827" />
              <Text style={styles.secondaryBtnText}>Export</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setStep('category')} style={styles.restartBtn}>
              <Text style={styles.restartBtnText}>Restart</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { marginTop: 20 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
  catBtn: { width: '48%', backgroundColor: '#FFFFFF', borderRadius: 24, padding: 24, alignItems: 'center', marginBottom: 12, borderWidth: 1, borderColor: '#F3F4F6', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.03, shadowRadius: 5 },
  catIconBox: { width: 40, height: 40, borderRadius: 12, backgroundColor: '#F3F4F6', alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
  catLabel: { fontSize: 10, fontWeight: '800', letterSpacing: 1.5, color: '#111827', textTransform: 'uppercase' },
  uploadArea: { spaceY: 16 },
  backBtn: { flexDirection: 'row', alignItems: 'center', marginBottom: 16 },
  backText: { fontSize: 10, fontWeight: '800', color: '#9CA3AF', letterSpacing: 1.5, marginLeft: 4, textTransform: 'uppercase' },
  dropzone: { backgroundColor: '#FFFFFF', borderRadius: 32, padding: 48, alignItems: 'center', borderWidth: 1, borderColor: '#F3F4F6', shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.03, shadowRadius: 10 },
  dropIcon: { width: 64, height: 64, borderRadius: 24, backgroundColor: '#F3F4F6', alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
  dropTitle: { fontSize: 14, fontWeight: '800', color: '#111827' },
  dropSub: { fontSize: 10, color: '#D1D5DB', fontWeight: '800', marginTop: 4, letterSpacing: 1 },
  configArea: {},
  configCard: { backgroundColor: '#FFFFFF', borderRadius: 24, padding: 20, borderWidth: 1, borderColor: '#E5E7EB', marginBottom: 20 },
  optionGroup: { marginBottom: 20 },
  optionLabel: { fontSize: 9, fontWeight: '800', color: '#9CA3AF', letterSpacing: 1.5, marginBottom: 8 },
  optionRow: { flexDirection: 'row', gap: 8 },
  optionBtn: { flex: 1, height: 44, borderRadius: 12, borderWidth: 1, borderColor: '#F3F4F6', alignItems: 'center', justifyContent: 'center' },
  optionBtnActive: { backgroundColor: '#111827', borderColor: '#111827' },
  optionBtnText: { fontSize: 11, fontWeight: '700', color: '#D1D5DB' },
  optionBtnTextActive: { color: '#FFFFFF' },
  primaryBtn: { height: 56, backgroundColor: '#111827', borderRadius: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 24 },
  btnContent: { flexDirection: 'row', alignItems: 'center' },
  btnText: { color: '#FFFFFF', fontSize: 14, fontWeight: '800', marginLeft: 10 },
  creditCost: { flexDirection: 'row', alignItems: 'center' },
  creditCostText: { color: '#FFFFFF', fontSize: 11, fontWeight: '900', marginLeft: 4, opacity: 0.6 },
  loaderArea: { paddingVertical: 60, alignItems: 'center' },
  loaderBox: { width: 96, height: 96, borderRadius: 32, backgroundColor: '#F3F4F6', alignItems: 'center', justifyContent: 'center', marginBottom: 24 },
  loaderTitle: { fontSize: 10, fontWeight: '800', color: '#111827', letterSpacing: 2 },
  loaderSub: { fontSize: 11, color: '#9CA3AF', fontWeight: '600', marginTop: 6 },
  resultArea: {},
  resultHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  resultTitle: { fontSize: 10, fontWeight: '800', color: '#111827', letterSpacing: 2 },
  certifiedBadge: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#111827', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  certifiedText: { color: '#FFFFFF', fontSize: 8, fontWeight: '800', letterSpacing: 1, marginLeft: 4 },
  imageContainer: { backgroundColor: '#FFFFFF', padding: 8, borderRadius: 32, borderWidth: 1, borderColor: '#F3F4F6' },
  resultImage: { width: '100%', aspectRatio: 1, borderRadius: 24, backgroundColor: '#F9FAFB' },
  resultActions: { flexDirection: 'row', gap: 12, marginTop: 24 },
  secondaryBtn: { flex: 1, height: 50, backgroundColor: '#FFFFFF', borderRadius: 12, borderWidth: 1, borderColor: '#E5E7EB', flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  secondaryBtnText: { fontSize: 12, fontWeight: '700', color: '#111827', marginLeft: 8 },
  restartBtn: { flex: 1, height: 50, backgroundColor: '#111827', borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  restartBtnText: { color: '#FFFFFF', fontSize: 12, fontWeight: '700' }
});
