
import React, { useState } from 'react';
import { 
  StyleSheet, 
  View, 
  Text, 
  TouchableOpacity, 
  ActivityIndicator,
  Dimensions
} from 'react-native';
import { Sparkles } from 'lucide-react-native';
import { UserProfile } from '../App';

const { width } = Dimensions.get('window');

interface LoginProps {
  onLogin: (user: UserProfile) => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [loading, setLoading] = useState<'Apple' | 'Google' | null>(null);

  const simulateLogin = (provider: 'Apple' | 'Google') => {
    setLoading(provider);
    setTimeout(() => {
      const mockUser: UserProfile = {
        name: provider === 'Apple' ? 'Creative User' : 'Studio Pro',
        email: provider === 'Apple' ? 'user@icloud.com' : 'studio@gmail.com',
        provider,
        credits: 5
      };
      onLogin(mockUser);
      setLoading(null);
    }, 1200);
  };

  return (
    <View style={styles.container}>
      <View style={styles.hero}>
        <View style={styles.logoBox}>
          <Sparkles size={40} color="#FFFFFF" />
        </View>
        <Text style={styles.title}>Vibe AI</Text>
        <Text style={styles.subtitle}>Minimal Product Staging Studio</Text>
      </View>

      <View style={styles.actions}>
        <TouchableOpacity
          onPress={() => simulateLogin('Apple')}
          style={styles.appleBtn}
          activeOpacity={0.8}
          disabled={!!loading}
        >
          {loading === 'Apple' ? (
            <ActivityIndicator color="#FFFFFF" />
          ) : (
            <>
              <AppleIcon />
              <Text style={styles.appleText}>Continue with Apple</Text>
            </>
          )}
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => simulateLogin('Google')}
          style={styles.googleBtn}
          activeOpacity={0.8}
          disabled={!!loading}
        >
          {loading === 'Google' ? (
            <ActivityIndicator color="#111827" />
          ) : (
            <>
              <GoogleIcon />
              <Text style={styles.googleText}>Sign in with Google</Text>
            </>
          )}
        </TouchableOpacity>

        <Text style={styles.disclaimer}>
          Professional product photography powered by minimal intelligence.
        </Text>
      </View>
    </View>
  );
};

const AppleIcon = () => (
  <View style={styles.iconContainer}>
    <Text style={{ color: 'white', fontSize: 18 }}></Text>
  </View>
);

const GoogleIcon = () => (
  <View style={[styles.iconContainer, { backgroundColor: '#111827', width: 16, height: 16, borderRadius: 8, alignItems: 'center', justifyContent: 'center' }]}>
    <Text style={{ color: 'white', fontSize: 10, fontWeight: 'bold' }}>G</Text>
  </View>
);

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FFFFFF', padding: 24 },
  hero: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  logoBox: { width: 80, height: 80, backgroundColor: '#111827', borderRadius: 24, alignItems: 'center', justifyContent: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.1, shadowRadius: 10 },
  title: { fontSize: 32, fontWeight: '800', color: '#111827', marginTop: 24, letterSpacing: -1 },
  subtitle: { fontSize: 14, color: '#9CA3AF', fontWeight: '600', marginTop: 4 },
  actions: { paddingBottom: 40 },
  appleBtn: { height: 56, backgroundColor: '#111827', borderRadius: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  appleText: { color: '#FFFFFF', fontSize: 16, fontWeight: '700', marginLeft: 10 },
  googleBtn: { height: 56, backgroundColor: '#FFFFFF', borderRadius: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginTop: 12, borderWidth: 1, borderColor: '#E5E7EB' },
  googleText: { color: '#111827', fontSize: 16, fontWeight: '700', marginLeft: 10 },
  iconContainer: { marginRight: 4 },
  disclaimer: { fontSize: 10, color: '#D1D5DB', fontWeight: '700', textAlign: 'center', textTransform: 'uppercase', letterSpacing: 1.5, marginTop: 24, paddingHorizontal: 40, lineHeight: 16 }
});
