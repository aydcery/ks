
import { GoogleGenAI } from "@google/genai";

export type ProductCategory = 'Accessories' | 'Clothes' | 'Furniture' | 'Electronics';

export interface GenerationOptions {
  category: ProductCategory;
  aspectRatio: '1:1' | '4:5' | '16:9';
  quality: 'Standard' | 'High';
}

/**
 * Native-ready Product Image Generation
 * Note: Actual React Native apps require environment variable handling via Config or similar.
 */
export async function generateProductImage(
  base64Image: string, 
  options: GenerationOptions
): Promise<string | null> {
  const modelName = options.quality === 'High' ? 'gemini-3-pro-image-preview' : 'gemini-2.5-flash-image';
  
  // Use a fallback or Config logic for Native
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

  try {
    // In a React Native environment, ensure the base64 string doesn't have the prefix
    const cleanBase64 = base64Image.includes('base64,') 
      ? base64Image.split('base64,')[1] 
      : base64Image;

    const prompt = `ACT AS A PROFESSIONAL COMMERCIAL PHOTOGRAPHER. 
    TASK: Place this product in a minimal, luxury grayscale ${options.category} setting.
    PRESERVE: Original product details perfectly.
    STYLE: High-end, photorealistic, 8k resolution.`;

    const response = await ai.models.generateContent({
      model: modelName,
      contents: {
        parts: [
          // Simulate image part if actual data exists, else mock successful response
          ...(cleanBase64 === 'mock_base64' ? [] : [{ inlineData: { data: cleanBase64, mimeType: 'image/png' } }]),
          { text: prompt }
        ]
      },
      config: {
        imageConfig: {
          aspectRatio: options.aspectRatio,
          ...(options.quality === 'High' ? { imageSize: "2K" } : {})
        }
      }
    });

    // Mocking native response if cleanBase64 was mock
    if (cleanBase64 === 'mock_base64') {
      return 'https://placehold.co/1024x1024/111827/FFFFFF?text=Staged+Product';
    }

    if (response.candidates && response.candidates[0].content.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          return `data:image/png;base64,${part.inlineData.data}`;
        }
      }
    }

    return null;
  } catch (error) {
    console.error("Native API Error:", error);
    throw error;
  }
}
